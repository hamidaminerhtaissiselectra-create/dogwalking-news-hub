# Présentation des Maquettes de Tableaux de Bord

Ce document regroupe les propositions de design pour les tableaux de bord **Propriétaire** et **Promeneur**, avec une attention particulière sur la navigation hybride (Desktop vs Mobile) et les interactions aux couleurs vives.

---

## 1. Concept de Navigation
Pour maximiser l'ergonomie, nous avons implémenté deux systèmes de navigation distincts :
- **Ordinateur (Desktop)** : Navigation via une barre latérale ou supérieure pour un accès rapide aux sections principales tout en gardant un large espace de travail.
- **Mobile** : Navigation via une **Barre d'Onglets Inférieure (Bottom Tab Bar)**, idéale pour une utilisation à une main, avec des icônes claires et un indicateur visuel sur l'onglet actif.

---

## 2. Maquettes par Onglet

### A. Onglet Accueil (Aperçu)
L'accueil sert de centre de commande avec des statistiques clés et des actions rapides.
- **Éléments vifs** : Boutons "Ajouter un chien" (Orange) et "Trouver un promeneur" (Bleu).
- **Navigation** : Sidebar à gauche (Desktop) / Barre en bas (Mobile).

### B. Onglet Missions (Réservations)
Gestion des balades à venir et de l'historique.
- **Éléments vifs** : Boutons "Modifier" (Orange vif) et "Contacter" (Vert vibrant).
- **Visualisation** : Liste claire avec badges de statut contrastés.

### C. Onglet Calendrier
Planification visuelle des services.
- **Éléments vifs** : Bouton "Réserver une promenade" (Vert émeraude) et marqueurs de couleur par type de service.
- **Adaptabilité** : Vue grille sur Desktop / Vue liste ou mini-calendrier sur Mobile.

### D. Onglet Gains (Spécifique Promeneur)
Suivi financier et performance.
- **Éléments vifs** : Bouton "Demander un retrait" (Jaune soleil / Or) et graphiques de progression.
- **Orientation** : Résumé des gains disponible immédiatement en bas sur mobile.

### E. Onglet Profil
Paramètres du compte et sécurité.
- **Éléments vifs** : Bouton "Enregistrer les modifications" (Vert forêt vif).
- **Clarté** : Formulaires aérés et téléchargement d'avatar simplifié.

---

## 3. Guide de Style des Interactions
| Action | Couleur | Pourquoi ? |
| :--- | :--- | :--- |
| **Création / Ajout** | Orange Corail | Dynamisme et visibilité immédiate. |
| **Confirmation / Succès** | Vert Émeraude | Sentiment de sécurité et de validation. |
| **Finances / Gains** | Jaune Or | Associé à la valeur et à la récompense. |
| **Navigation / Recherche** | Bleu Électrique | Professionnalisme et clarté technique. |
| **Alertes / Refus** | Rouge Cerise | Attention immédiate requise. |
